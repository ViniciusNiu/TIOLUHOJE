﻿namespace ProjetoPastelariaDoZe_2022
{
    partial class Controle_de_Estoque_do_Zé
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Controle_de_Estoque_do_Zé));
            this.buttonFuncEstoque = new System.Windows.Forms.Button();
            this.labelTituloEstoque = new System.Windows.Forms.Label();
            this.buttonCliEstoque = new System.Windows.Forms.Button();
            this.buttonConfigEstoque = new System.Windows.Forms.Button();
            this.buttonCadEstoque = new System.Windows.Forms.Button();
            this.buttonSobreEstoque = new System.Windows.Forms.Button();
            this.contextMenuStripPrincipal = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.controleDeEstoqueDoZéToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.funcionáriosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cadastroDeClientesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cadastroProdutoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sobreToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.configuraçõesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loginToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sairToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.notifyIconSystemTray = new System.Windows.Forms.NotifyIcon(this.components);
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.sairToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.abrirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sobreToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStripPrincipal.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonFuncEstoque
            // 
            this.buttonFuncEstoque.Location = new System.Drawing.Point(286, 95);
            this.buttonFuncEstoque.Name = "buttonFuncEstoque";
            this.buttonFuncEstoque.Size = new System.Drawing.Size(208, 32);
            this.buttonFuncEstoque.TabIndex = 1;
            this.buttonFuncEstoque.Text = "Cadastro Funcionários";
            this.buttonFuncEstoque.UseVisualStyleBackColor = true;
            this.buttonFuncEstoque.Click += new System.EventHandler(this.button1_Click);
            // 
            // labelTituloEstoque
            // 
            this.labelTituloEstoque.AutoSize = true;
            this.labelTituloEstoque.Font = new System.Drawing.Font("SimSun", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.labelTituloEstoque.Location = new System.Drawing.Point(204, 24);
            this.labelTituloEstoque.Name = "labelTituloEstoque";
            this.labelTituloEstoque.Size = new System.Drawing.Size(157, 37);
            this.labelTituloEstoque.TabIndex = 1;
            this.labelTituloEstoque.Text = "Control";
            // 
            // buttonCliEstoque
            // 
            this.buttonCliEstoque.Location = new System.Drawing.Point(286, 145);
            this.buttonCliEstoque.Name = "buttonCliEstoque";
            this.buttonCliEstoque.Size = new System.Drawing.Size(208, 32);
            this.buttonCliEstoque.TabIndex = 2;
            this.buttonCliEstoque.Text = "Cadastro Clientes";
            this.buttonCliEstoque.UseVisualStyleBackColor = true;
            this.buttonCliEstoque.Click += new System.EventHandler(this.button2_Click);
            // 
            // buttonConfigEstoque
            // 
            this.buttonConfigEstoque.Location = new System.Drawing.Point(286, 247);
            this.buttonConfigEstoque.Name = "buttonConfigEstoque";
            this.buttonConfigEstoque.Size = new System.Drawing.Size(208, 32);
            this.buttonConfigEstoque.TabIndex = 4;
            this.buttonConfigEstoque.Text = "Configurações";
            this.buttonConfigEstoque.UseVisualStyleBackColor = true;
            this.buttonConfigEstoque.Click += new System.EventHandler(this.button3_Click);
            // 
            // buttonCadEstoque
            // 
            this.buttonCadEstoque.Location = new System.Drawing.Point(286, 197);
            this.buttonCadEstoque.Name = "buttonCadEstoque";
            this.buttonCadEstoque.Size = new System.Drawing.Size(208, 32);
            this.buttonCadEstoque.TabIndex = 3;
            this.buttonCadEstoque.Text = "Cadastro Produtos";
            this.buttonCadEstoque.UseVisualStyleBackColor = true;
            this.buttonCadEstoque.Click += new System.EventHandler(this.button4_Click);
            // 
            // buttonSobreEstoque
            // 
            this.buttonSobreEstoque.Location = new System.Drawing.Point(286, 297);
            this.buttonSobreEstoque.Name = "buttonSobreEstoque";
            this.buttonSobreEstoque.Size = new System.Drawing.Size(208, 32);
            this.buttonSobreEstoque.TabIndex = 5;
            this.buttonSobreEstoque.Text = "Sobre";
            this.buttonSobreEstoque.UseVisualStyleBackColor = true;
            this.buttonSobreEstoque.Click += new System.EventHandler(this.button5_Click);
            // 
            // contextMenuStripPrincipal
            // 
            this.contextMenuStripPrincipal.BackColor = System.Drawing.Color.Yellow;
            this.contextMenuStripPrincipal.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.controleDeEstoqueDoZéToolStripMenuItem,
            this.funcionáriosToolStripMenuItem,
            this.cadastroDeClientesToolStripMenuItem,
            this.cadastroProdutoToolStripMenuItem,
            this.sobreToolStripMenuItem,
            this.configuraçõesToolStripMenuItem,
            this.loginToolStripMenuItem,
            this.sairToolStripMenuItem});
            this.contextMenuStripPrincipal.Name = "contextMenuStripPrincipal";
            this.contextMenuStripPrincipal.Size = new System.Drawing.Size(266, 180);
            this.contextMenuStripPrincipal.Text = "AAAAAAAAA";
            this.contextMenuStripPrincipal.Opening += new System.ComponentModel.CancelEventHandler(this.contextMenuStripPrincipal_Opening);
            // 
            // controleDeEstoqueDoZéToolStripMenuItem
            // 
            this.controleDeEstoqueDoZéToolStripMenuItem.Name = "controleDeEstoqueDoZéToolStripMenuItem";
            this.controleDeEstoqueDoZéToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Shift | System.Windows.Forms.Keys.F1)));
            this.controleDeEstoqueDoZéToolStripMenuItem.Size = new System.Drawing.Size(265, 22);
            this.controleDeEstoqueDoZéToolStripMenuItem.Text = "Controle de Estoque do Zé";
            this.controleDeEstoqueDoZéToolStripMenuItem.Click += new System.EventHandler(this.controleDeEstoqueDoZéToolStripMenuItem_Click);
            // 
            // funcionáriosToolStripMenuItem
            // 
            this.funcionáriosToolStripMenuItem.Name = "funcionáriosToolStripMenuItem";
            this.funcionáriosToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Shift | System.Windows.Forms.Keys.F2)));
            this.funcionáriosToolStripMenuItem.Size = new System.Drawing.Size(265, 22);
            this.funcionáriosToolStripMenuItem.Text = "Cadastro de  Funcionários";
            this.funcionáriosToolStripMenuItem.Click += new System.EventHandler(this.funcionáriosToolStripMenuItem_Click);
            // 
            // cadastroDeClientesToolStripMenuItem
            // 
            this.cadastroDeClientesToolStripMenuItem.Name = "cadastroDeClientesToolStripMenuItem";
            this.cadastroDeClientesToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Shift | System.Windows.Forms.Keys.F3)));
            this.cadastroDeClientesToolStripMenuItem.Size = new System.Drawing.Size(265, 22);
            this.cadastroDeClientesToolStripMenuItem.Text = "Cadastro de Clientes";
            this.cadastroDeClientesToolStripMenuItem.Click += new System.EventHandler(this.cadastroDeClientesToolStripMenuItem_Click);
            // 
            // cadastroProdutoToolStripMenuItem
            // 
            this.cadastroProdutoToolStripMenuItem.Name = "cadastroProdutoToolStripMenuItem";
            this.cadastroProdutoToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Shift | System.Windows.Forms.Keys.F4)));
            this.cadastroProdutoToolStripMenuItem.Size = new System.Drawing.Size(265, 22);
            this.cadastroProdutoToolStripMenuItem.Text = "Cadastro de Produtos";
            this.cadastroProdutoToolStripMenuItem.Click += new System.EventHandler(this.cadastroProdutoToolStripMenuItem_Click);
            // 
            // sobreToolStripMenuItem
            // 
            this.sobreToolStripMenuItem.Name = "sobreToolStripMenuItem";
            this.sobreToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Shift | System.Windows.Forms.Keys.F8)));
            this.sobreToolStripMenuItem.Size = new System.Drawing.Size(265, 22);
            this.sobreToolStripMenuItem.Text = "Sobre";
            this.sobreToolStripMenuItem.Click += new System.EventHandler(this.sobreToolStripMenuItem_Click);
            // 
            // configuraçõesToolStripMenuItem
            // 
            this.configuraçõesToolStripMenuItem.Name = "configuraçõesToolStripMenuItem";
            this.configuraçõesToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Shift | System.Windows.Forms.Keys.F9)));
            this.configuraçõesToolStripMenuItem.Size = new System.Drawing.Size(265, 22);
            this.configuraçõesToolStripMenuItem.Text = "Configurações";
            this.configuraçõesToolStripMenuItem.Click += new System.EventHandler(this.configuraçõesToolStripMenuItem_Click);
            // 
            // loginToolStripMenuItem
            // 
            this.loginToolStripMenuItem.Name = "loginToolStripMenuItem";
            this.loginToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Shift | System.Windows.Forms.Keys.F10)));
            this.loginToolStripMenuItem.Size = new System.Drawing.Size(265, 22);
            this.loginToolStripMenuItem.Text = "Login";
            this.loginToolStripMenuItem.Click += new System.EventHandler(this.loginToolStripMenuItem_Click);
            // 
            // sairToolStripMenuItem
            // 
            this.sairToolStripMenuItem.Name = "sairToolStripMenuItem";
            this.sairToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Shift | System.Windows.Forms.Keys.F11)));
            this.sairToolStripMenuItem.Size = new System.Drawing.Size(265, 22);
            this.sairToolStripMenuItem.Text = "Sair";
            this.sairToolStripMenuItem.Click += new System.EventHandler(this.sairToolStripMenuItem_Click);
            // 
            // notifyIconSystemTray
            // 
            this.notifyIconSystemTray.BalloonTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            this.notifyIconSystemTray.BalloonTipText = "O aplicativo continua rodando na bandeja.";
            this.notifyIconSystemTray.BalloonTipTitle = "Pastelaria do Zé";
            this.notifyIconSystemTray.ContextMenuStrip = this.contextMenuStrip1;
            this.notifyIconSystemTray.Icon = ((System.Drawing.Icon)(resources.GetObject("notifyIconSystemTray.Icon")));
            this.notifyIconSystemTray.Text = "Pastelaria do Zé";
            this.notifyIconSystemTray.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.notifyIcon1_MouseDoubleClick);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sairToolStripMenuItem1,
            this.abrirToolStripMenuItem,
            this.sobreToolStripMenuItem1});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(181, 92);
            // 
            // sairToolStripMenuItem1
            // 
            this.sairToolStripMenuItem1.Name = "sairToolStripMenuItem1";
            this.sairToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.sairToolStripMenuItem1.Text = "Sair";
            this.sairToolStripMenuItem1.Click += new System.EventHandler(this.sairToolStripMenuItem1_Click);
            // 
            // abrirToolStripMenuItem
            // 
            this.abrirToolStripMenuItem.Name = "abrirToolStripMenuItem";
            this.abrirToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.abrirToolStripMenuItem.Text = "Abrir";
            this.abrirToolStripMenuItem.Click += new System.EventHandler(this.abrirToolStripMenuItem_Click);
            // 
            // sobreToolStripMenuItem1
            // 
            this.sobreToolStripMenuItem1.Name = "sobreToolStripMenuItem1";
            this.sobreToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.sobreToolStripMenuItem1.Text = "Sobre";
            this.sobreToolStripMenuItem1.Click += new System.EventHandler(this.sobreToolStripMenuItem1_Click);
            // 
            // Controle_de_Estoque_do_Zé
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Yellow;
            this.ClientSize = new System.Drawing.Size(773, 402);
            this.ContextMenuStrip = this.contextMenuStripPrincipal;
            this.Controls.Add(this.buttonSobreEstoque);
            this.Controls.Add(this.buttonConfigEstoque);
            this.Controls.Add(this.buttonCadEstoque);
            this.Controls.Add(this.buttonCliEstoque);
            this.Controls.Add(this.labelTituloEstoque);
            this.Controls.Add(this.buttonFuncEstoque);
            this.KeyPreview = true;
            this.Name = "Controle_de_Estoque_do_Zé";
            this.Text = "Controle_de_Estoque_do_Zé";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Controle_de_Estoque_do_Zé_FormClosing);
            this.Load += new System.EventHandler(this.Controle_de_Estoque_do_Zé_Load);
            this.Resize += new System.EventHandler(this.Controle_de_Estoque_do_Zé_Resize);
            this.contextMenuStripPrincipal.ResumeLayout(false);
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button buttonFuncEstoque;
        private Label labelTituloEstoque;
        private Button buttonCliEstoque;
        private Button buttonConfigEstoque;
        private Button buttonCadEstoque;
        private Button buttonSobreEstoque;
        private ContextMenuStrip contextMenuStripPrincipal;
        private ToolStripMenuItem controleDeEstoqueDoZéToolStripMenuItem;
        private ToolStripMenuItem funcionáriosToolStripMenuItem;
        private ToolStripMenuItem cadastroDeClientesToolStripMenuItem;
        private ToolStripMenuItem cadastroProdutoToolStripMenuItem;
        private ToolStripMenuItem sobreToolStripMenuItem;
        private ToolStripMenuItem configuraçõesToolStripMenuItem;
        private ToolStripMenuItem loginToolStripMenuItem;
        private ToolStripMenuItem sairToolStripMenuItem;
        private NotifyIcon notifyIconSystemTray;
        private ContextMenuStrip contextMenuStrip1;
        private ToolStripMenuItem sairToolStripMenuItem1;
        private ToolStripMenuItem abrirToolStripMenuItem;
        private ToolStripMenuItem sobreToolStripMenuItem1;
    }
}