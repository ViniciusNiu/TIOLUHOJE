﻿namespace ProjetoPastelariaDoZe_2022
{
    partial class Clientes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Clientes));
            this.labelReSenhaCliente = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.labelSenhaCliente = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.labelTelefoneCliente = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.labelNomeCliente = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.labelCpfCliente = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.labelidCliente = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.labelTituloCliente = new System.Windows.Forms.Label();
            this.labelMarcaFiadoCliente = new System.Windows.Forms.Label();
            this.labelDiaFiadoCliente = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.buttonVoltarCliente = new System.Windows.Forms.Button();
            this.buttonConcluirCliente = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.dataGridViewDados = new System.Windows.Forms.DataGridView();
            this.clienteDAOBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.button2 = new System.Windows.Forms.Button();
            this.buttonEditar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDados)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.clienteDAOBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // labelReSenhaCliente
            // 
            this.labelReSenhaCliente.AutoSize = true;
            this.labelReSenhaCliente.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.labelReSenhaCliente.Location = new System.Drawing.Point(321, 379);
            this.labelReSenhaCliente.Name = "labelReSenhaCliente";
            this.labelReSenhaCliente.Size = new System.Drawing.Size(96, 25);
            this.labelReSenhaCliente.TabIndex = 36;
            this.labelReSenhaCliente.Text = "Re-Senha:";
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(321, 407);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(246, 23);
            this.textBox7.TabIndex = 8;
            this.textBox7.TextChanged += new System.EventHandler(this.textBox7_TextChanged);
            // 
            // labelSenhaCliente
            // 
            this.labelSenhaCliente.AutoSize = true;
            this.labelSenhaCliente.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.labelSenhaCliente.Location = new System.Drawing.Point(12, 379);
            this.labelSenhaCliente.Name = "labelSenhaCliente";
            this.labelSenhaCliente.Size = new System.Drawing.Size(68, 25);
            this.labelSenhaCliente.TabIndex = 34;
            this.labelSenhaCliente.Text = "Senha:";
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(12, 407);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(246, 23);
            this.textBox6.TabIndex = 7;
            // 
            // labelTelefoneCliente
            // 
            this.labelTelefoneCliente.AutoSize = true;
            this.labelTelefoneCliente.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.labelTelefoneCliente.Location = new System.Drawing.Point(12, 247);
            this.labelTelefoneCliente.Name = "labelTelefoneCliente";
            this.labelTelefoneCliente.Size = new System.Drawing.Size(87, 25);
            this.labelTelefoneCliente.TabIndex = 31;
            this.labelTelefoneCliente.Text = "Telefone:";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(12, 275);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(210, 23);
            this.textBox5.TabIndex = 4;
            // 
            // labelNomeCliente
            // 
            this.labelNomeCliente.AutoSize = true;
            this.labelNomeCliente.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.labelNomeCliente.Location = new System.Drawing.Point(12, 162);
            this.labelNomeCliente.Name = "labelNomeCliente";
            this.labelNomeCliente.Size = new System.Drawing.Size(67, 25);
            this.labelNomeCliente.TabIndex = 29;
            this.labelNomeCliente.Text = "Nome:";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(12, 190);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(747, 23);
            this.textBox4.TabIndex = 3;
            // 
            // labelCpfCliente
            // 
            this.labelCpfCliente.AutoSize = true;
            this.labelCpfCliente.Location = new System.Drawing.Point(126, 75);
            this.labelCpfCliente.Name = "labelCpfCliente";
            this.labelCpfCliente.Size = new System.Drawing.Size(31, 15);
            this.labelCpfCliente.TabIndex = 25;
            this.labelCpfCliente.Text = "CPF:";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(126, 93);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(160, 23);
            this.textBox2.TabIndex = 2;
            // 
            // labelidCliente
            // 
            this.labelidCliente.AutoSize = true;
            this.labelidCliente.Location = new System.Drawing.Point(12, 75);
            this.labelidCliente.Name = "labelidCliente";
            this.labelidCliente.Size = new System.Drawing.Size(21, 15);
            this.labelidCliente.TabIndex = 23;
            this.labelidCliente.Text = "ID:";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(12, 93);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(61, 23);
            this.textBox1.TabIndex = 1;
            // 
            // labelTituloCliente
            // 
            this.labelTituloCliente.AutoSize = true;
            this.labelTituloCliente.Font = new System.Drawing.Font("SimSun", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.labelTituloCliente.Location = new System.Drawing.Point(95, 9);
            this.labelTituloCliente.Name = "labelTituloCliente";
            this.labelTituloCliente.Size = new System.Drawing.Size(252, 27);
            this.labelTituloCliente.TabIndex = 19;
            this.labelTituloCliente.Text = "Cadastro Cliente";
            // 
            // labelMarcaFiadoCliente
            // 
            this.labelMarcaFiadoCliente.AutoSize = true;
            this.labelMarcaFiadoCliente.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.labelMarcaFiadoCliente.Location = new System.Drawing.Point(305, 247);
            this.labelMarcaFiadoCliente.Name = "labelMarcaFiadoCliente";
            this.labelMarcaFiadoCliente.Size = new System.Drawing.Size(120, 25);
            this.labelMarcaFiadoCliente.TabIndex = 38;
            this.labelMarcaFiadoCliente.Text = "Marca Fiado:";
            // 
            // labelDiaFiadoCliente
            // 
            this.labelDiaFiadoCliente.AutoSize = true;
            this.labelDiaFiadoCliente.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.labelDiaFiadoCliente.Location = new System.Drawing.Point(544, 247);
            this.labelDiaFiadoCliente.Name = "labelDiaFiadoCliente";
            this.labelDiaFiadoCliente.Size = new System.Drawing.Size(95, 25);
            this.labelDiaFiadoCliente.TabIndex = 39;
            this.labelDiaFiadoCliente.Text = "Dia Fiado:";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Sim",
            "Não"});
            this.comboBox1.Location = new System.Drawing.Point(304, 275);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 23);
            this.comboBox1.TabIndex = 5;
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(544, 276);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(120, 23);
            this.numericUpDown1.TabIndex = 6;
            this.numericUpDown1.ValueChanged += new System.EventHandler(this.numericUpDown1_ValueChanged);
            // 
            // buttonVoltarCliente
            // 
            this.buttonVoltarCliente.Location = new System.Drawing.Point(621, 407);
            this.buttonVoltarCliente.Name = "buttonVoltarCliente";
            this.buttonVoltarCliente.Size = new System.Drawing.Size(75, 23);
            this.buttonVoltarCliente.TabIndex = 9;
            this.buttonVoltarCliente.Text = "Voltar";
            this.buttonVoltarCliente.UseVisualStyleBackColor = true;
            this.buttonVoltarCliente.Click += new System.EventHandler(this.buttonVoltarCliente_Click);
            // 
            // buttonConcluirCliente
            // 
            this.buttonConcluirCliente.Location = new System.Drawing.Point(713, 407);
            this.buttonConcluirCliente.Name = "buttonConcluirCliente";
            this.buttonConcluirCliente.Size = new System.Drawing.Size(75, 23);
            this.buttonConcluirCliente.TabIndex = 10;
            this.buttonConcluirCliente.Text = "Concluir";
            this.buttonConcluirCliente.UseVisualStyleBackColor = true;
            this.buttonConcluirCliente.Click += new System.EventHandler(this.buttonConcluirCliente_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(11, 9);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(78, 38);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 44;
            this.pictureBox1.TabStop = false;
            // 
            // dataGridViewDados
            // 
            this.dataGridViewDados.AllowUserToAddRows = false;
            this.dataGridViewDados.AutoGenerateColumns = false;
            this.dataGridViewDados.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGridViewDados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewDados.DataSource = this.clienteDAOBindingSource;
            this.dataGridViewDados.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dataGridViewDados.Location = new System.Drawing.Point(831, 9);
            this.dataGridViewDados.MultiSelect = false;
            this.dataGridViewDados.Name = "dataGridViewDados";
            this.dataGridViewDados.RowTemplate.Height = 25;
            this.dataGridViewDados.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewDados.Size = new System.Drawing.Size(367, 415);
            this.dataGridViewDados.TabIndex = 45;
            this.dataGridViewDados.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewDados_CellContentClick);
            // 
            // clienteDAOBindingSource
            // 
            this.clienteDAOBindingSource.DataSource = typeof(ProjetoPastelariaDoZe_2022.DAO.ClienteDAO);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(712, 378);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 104;
            this.button2.Text = "Excluir";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // buttonEditar
            // 
            this.buttonEditar.Location = new System.Drawing.Point(621, 378);
            this.buttonEditar.Name = "buttonEditar";
            this.buttonEditar.Size = new System.Drawing.Size(75, 23);
            this.buttonEditar.TabIndex = 103;
            this.buttonEditar.Text = "Editar";
            this.buttonEditar.UseVisualStyleBackColor = true;
            this.buttonEditar.Click += new System.EventHandler(this.buttonEditar_Click);
            // 
            // Clientes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Yellow;
            this.ClientSize = new System.Drawing.Size(1220, 450);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.buttonEditar);
            this.Controls.Add(this.dataGridViewDados);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.buttonConcluirCliente);
            this.Controls.Add(this.buttonVoltarCliente);
            this.Controls.Add(this.numericUpDown1);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.labelDiaFiadoCliente);
            this.Controls.Add(this.labelMarcaFiadoCliente);
            this.Controls.Add(this.labelReSenhaCliente);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.labelSenhaCliente);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.labelTelefoneCliente);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.labelNomeCliente);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.labelCpfCliente);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.labelidCliente);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.labelTituloCliente);
            this.KeyPreview = true;
            this.Name = "Clientes";
            this.Text = "Clientes";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Clientes_FormClosing);
            this.Load += new System.EventHandler(this.Clientes_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDados)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.clienteDAOBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Label labelReSenhaCliente;
        private TextBox textBox7;
        private Label labelSenhaCliente;
        private TextBox textBox6;
        private Label labelTelefoneCliente;
        private TextBox textBox5;
        private Label labelNomeCliente;
        private TextBox textBox4;
        private Label labelCpfCliente;
        private TextBox textBox2;
        private Label labelidCliente;
        private TextBox textBox1;
        private Label labelTituloCliente;
        private Label labelMarcaFiadoCliente;
        private Label labelDiaFiadoCliente;
        private ComboBox comboBox1;
        private NumericUpDown numericUpDown1;
        private Button buttonVoltarCliente;
        private Button buttonConcluirCliente;
        private PictureBox pictureBox1;
        private DataGridView dataGridViewDados;
        private BindingSource clienteDAOBindingSource;
        private Button button2;
        private Button buttonEditar;
    }
}